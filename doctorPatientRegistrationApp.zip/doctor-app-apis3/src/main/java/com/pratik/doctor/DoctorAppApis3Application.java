package com.pratik.doctor;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.pratik.doctor.services.FileService;

@SpringBootApplication
public class DoctorAppApis3Application {

	public static void main(String[] args) {
	  SpringApplication.run(DoctorAppApis3Application.class, args);
	}
	
	
	@Bean
	public ModelMapper modelMapper()
	{
		return new ModelMapper();
	}
	

	

}
