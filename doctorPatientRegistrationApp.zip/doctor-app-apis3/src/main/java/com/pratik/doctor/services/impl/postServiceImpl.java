package com.pratik.doctor.services.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pratik.doctor.entities.Patient;
import com.pratik.doctor.entities.doctor;
import com.pratik.doctor.entities.post;
import com.pratik.doctor.exceptions.ResourceNotFoundException;
import com.pratik.doctor.payloads.postDto;
import com.pratik.doctor.repositories.PatientRepo;
import com.pratik.doctor.repositories.postRepo;
import com.pratik.doctor.repositories.userRepo;
import com.pratik.doctor.services.postService;



@Service
public class postServiceImpl implements postService {
	
	
	@Autowired
	private postRepo postRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	  
	
	@Autowired
	private userRepo userRepo;
	
	@Autowired
	private PatientRepo patientRepo; 

	@Override
	public postDto createPost(postDto postDto1,Integer doctorId,Integer patientId) {
		
		doctor doctor1=this.userRepo.findById(doctorId)
				.orElseThrow(() ->  new ResourceNotFoundException("doctor", "id", doctorId));
		
		
		Patient patient=this.patientRepo.findById(patientId)
				.orElseThrow(()-> new ResourceNotFoundException("Patient","patientId",patientId));
		post post1=this.modelMapper.map(postDto1, post.class);
		post1.setImageName("default.png");
		post1.setAddDate(new Date());
		post1.setDoctor1(doctor1);
		post1.setPatient(patient);
		
		
		post newPost=this.postRepo.save(post1);
		
		
		
		return this.modelMapper.map(newPost, postDto.class);
	}

	@Override
	public postDto updatePost(postDto postDto1, Integer postId) {
		post post1=this.postRepo.findById(postId)
				.orElseThrow(() -> new ResourceNotFoundException("post", "postId",postId));
		
		post1.setPostTitle(postDto1.getPostTitle());
		post1.setPostContent(postDto1.getPostContent());
		post1.setImageName(postDto1.getImageName());
		post updatedPost=this.postRepo.save(post1);
		return this.modelMapper.map(updatedPost, postDto.class);
	}

	@Override
	public void deletePost(Integer postId) {
		post post1=this.postRepo.findById(postId)
		.orElseThrow(() -> new ResourceNotFoundException("post", "postId",postId));
		
		this.postRepo.delete(post1);

	}

	@Override
	public List<postDto> getAllPost() {
		List<post> allPosts=this.postRepo.findAll();
		List<postDto> postDtos=allPosts.stream().map((post)-> this.modelMapper.map(post, postDto.class))
		.collect(Collectors.toList());
		return postDtos;
	}

	@Override
	public postDto getPostById(Integer postId) {
		post post1=this.postRepo.findById(postId)
		.orElseThrow(() -> new ResourceNotFoundException("post","postId", postId));
		return this.modelMapper.map(post1, postDto.class);
	}

	@Override
	public List<postDto> getPostsByPatient(Integer patientId) {
		Patient patient=this.patientRepo.findById(patientId)
				.orElseThrow(() -> new ResourceNotFoundException("Patient", "patientId",patientId));
		List<post> posts=this.postRepo.findByPatient(patient);
		List<postDto> postDtos=posts.stream().map(post-> this.modelMapper.map(post, postDto.class))
		.collect(Collectors.toList());
		return postDtos;
	}

	@Override
	public List<postDto> getPostsByDoctor(Integer doctorId) {
		doctor doctor1=this.userRepo.findById(doctorId)
				.orElseThrow(() -> new ResourceNotFoundException("doctor", "id", doctorId));
		List<post> posts=this.postRepo.findByDoctor1(doctor1);
		List<postDto> postDtos=posts.stream().map((post)-> this.modelMapper.map(post, postDto.class))
		.collect(Collectors.toList());
		return postDtos;
	}

	@Override
	public List<postDto> searchPosts(String keyword) {
		List<post> posts=this.postRepo.searchByPostTitle("%"+keyword + "%");
		List<postDto> postDtos=posts.stream().map((post) -> this.modelMapper.map(post, postDto.class))
		.collect(Collectors.toList());
		return postDtos;
	}

}
