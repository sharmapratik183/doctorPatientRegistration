package com.pratik.doctor.payloads;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter

public class doctorDto {
	
	private int id;
	
	
	@Size(min = 3,message="Name must be atleast 3 characters")
	private String name;
	
    @Email(message="Please Enter A Valid Email Address")
	private String email;
	
	
    @Size(max=20,message="City can not be more than 20 characters")
	private String city;
	
	
	@Size(min=10,message="Phone Number can not be less than 10 digits")
	private String phone;
	
	
	
	private String speciality;

}
