package com.pratik.doctor.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pratik.doctor.entities.Patient;
import com.pratik.doctor.entities.doctor;
import com.pratik.doctor.entities.post;



public interface postRepo extends JpaRepository<post, Integer> {
	
	
	List<post> findByDoctor1(doctor doctor1);
	
	
	
	List<post> findByPatient(Patient patient1);
	
	
	@Query("select p from post p where p.postTitle like :key")
	List<post> searchByPostTitle(@Param("key") String postTitle);
	
	
	

}
