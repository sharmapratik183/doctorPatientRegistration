package com.pratik.doctor.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="Patient")
@NoArgsConstructor
@Getter
@Setter
public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer patientId;
	
	
	@Column(name="Name",length=100,nullable = false)
	private String patientName;
	
	@Column(name="City",nullable = false)
	private String patientCity;
	
	
	@Column(name="Email",nullable = false)
	private String patientEmail;
	
	
	@Column(name="Phone",nullable = false)
	private String patientPhone;
	
	
	@Column(name="Symptoms",nullable = false)
	private String patientSymptoms;
	
	@OneToMany(mappedBy="patient",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<post> posts=new ArrayList<>();
	
	
	

}
