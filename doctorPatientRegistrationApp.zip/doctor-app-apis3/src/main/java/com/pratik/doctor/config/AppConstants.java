package com.pratik.doctor.config;

public class AppConstants {

}
