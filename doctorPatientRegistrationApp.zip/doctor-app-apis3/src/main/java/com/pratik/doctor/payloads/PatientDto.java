package com.pratik.doctor.payloads;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class PatientDto {
	
	private Integer patientId;
	
	@NotBlank
	@Size(min=3,message="Name can not be less than 3 words")
	private String patientName;
	
	@NotBlank
	@Size(max=20,message="City can not be more than 20 words")
	private String patientCity;
	
	@NotBlank
	@Email(message="Please enter a valid email address")
	private String patientEmail;
	
	
	@NotBlank
	@Size(min=10,message="Phone no. can not be less than 10 digits")
	private String patientPhone;
	
	@NotBlank
	private String patientSymptoms;
	 
	

}
