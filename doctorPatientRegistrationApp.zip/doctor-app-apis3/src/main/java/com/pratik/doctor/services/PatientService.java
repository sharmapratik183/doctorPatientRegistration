package com.pratik.doctor.services;

import java.util.List;

import com.pratik.doctor.payloads.PatientDto;

public interface PatientService {
	
	public PatientDto createPatient(PatientDto patientDto);
	
	
	
	public PatientDto updatePatient(PatientDto patientDto,Integer patientId);
	
	
	
	public void deletePatient(Integer patientId);
	
	
	public PatientDto getPatient(Integer patientId);
	
	public List<PatientDto> getPatients();
	

}
