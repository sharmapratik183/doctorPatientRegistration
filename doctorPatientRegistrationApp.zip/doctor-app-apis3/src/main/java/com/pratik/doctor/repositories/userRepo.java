package com.pratik.doctor.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pratik.doctor.entities.doctor;

public interface userRepo extends JpaRepository<doctor, Integer> {

}
