package com.pratik.doctor.services.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pratik.doctor.entities.Patient;
import com.pratik.doctor.exceptions.ResourceNotFoundException;
import com.pratik.doctor.payloads.PatientDto;
import com.pratik.doctor.repositories.PatientRepo;
import com.pratik.doctor.services.PatientService;
@Service
public class PatientServiceImpl implements PatientService {
	@Autowired
	private PatientRepo patientRepo;
	
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public PatientDto createPatient(PatientDto patientDto) {
		Patient patient=this.modelMapper.map(patientDto, Patient.class);
		Patient addedPatient=this.patientRepo.save(patient);
		return this.modelMapper.map(addedPatient, PatientDto.class);
	}

	@Override
	public PatientDto updatePatient(PatientDto patientDto, Integer patientId) {
		Patient patient=this.patientRepo.findById(patientId)
				.orElseThrow(()-> new ResourceNotFoundException("Patient", "patientId", patientId));
		patient.setPatientName(patientDto.getPatientName());
		patient.setPatientEmail(patientDto.getPatientEmail());
		patient.setPatientCity(patientDto.getPatientCity());
		patient.setPatientPhone(patientDto.getPatientPhone());
		patient.setPatientSymptoms(patientDto.getPatientSymptoms());
		Patient updatedPatient=this.patientRepo.save(patient);
		return this.modelMapper.map(updatedPatient, PatientDto.class);
	}

	@Override
	public void deletePatient(Integer patientId) {
		Patient patient=this.patientRepo.findById(patientId).orElseThrow(() -> new ResourceNotFoundException("Patient", "patientId",patientId));
		this.patientRepo.delete(patient);

	}

	@Override
	public PatientDto getPatient(Integer patientId) {
		Patient patient=this.patientRepo.findById(patientId).orElseThrow(() -> new ResourceNotFoundException("Patient", "patientId",patientId));
		
		return this.modelMapper.map(patient, PatientDto.class);
	}

	@Override
	public List<PatientDto> getPatients() {
		List<Patient> patients=this.patientRepo.findAll();
		List<PatientDto> patientDtos=patients.stream().map((patient) -> this.modelMapper.map(patient, PatientDto.class)).collect(Collectors.toList());
		return patientDtos;
	}

}
