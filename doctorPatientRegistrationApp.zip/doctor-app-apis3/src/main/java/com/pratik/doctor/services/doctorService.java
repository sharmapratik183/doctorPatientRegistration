package com.pratik.doctor.services;

import java.util.List;
import java.util.Optional;

import com.pratik.doctor.payloads.doctorDto;



public interface doctorService {
	
	doctorDto createDoctor(doctorDto doctor);
	doctorDto updateDoctor(doctorDto doctorDto,Integer doctorId);
	doctorDto getDoctorById(Integer doctorId);
	List<doctorDto> getAllDoctors();
	
	void deleteDoctor(Integer doctorId);
	
	

}
