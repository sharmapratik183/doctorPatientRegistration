package com.pratik.doctor.payloads;

import java.util.Date;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.pratik.doctor.entities.Patient;
import com.pratik.doctor.entities.doctor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
public class postDto {
	
	
	private Integer postId;
	
	
	private String postTitle;
	
	
	private String postContent;
	
	
	private String imageName;
	
	
	private Date addDate;
	
	
    private PatientDto patient;
	
	private doctorDto doctor1;

}
