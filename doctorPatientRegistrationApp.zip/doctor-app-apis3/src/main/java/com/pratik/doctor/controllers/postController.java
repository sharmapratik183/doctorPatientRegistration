package com.pratik.doctor.controllers;


import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.pratik.doctor.payloads.ApiResponse;
import com.pratik.doctor.payloads.PatientDto;
import com.pratik.doctor.payloads.postDto;
import com.pratik.doctor.services.FileService;
import com.pratik.doctor.services.PatientService;
import com.pratik.doctor.services.postService;

@RestController
@RequestMapping("/api/") 
public class postController {
	
	
	
	@Autowired
	private postService postService1;
	
	
	@Autowired
	private FileService fileService ;
	
	@Value("$(project.image)")
	private String path;
	
	
	@PostMapping("/doctor1/{doctorId}/patient/{patientId}/posts")
	public ResponseEntity<postDto> createPost(@Valid @RequestBody postDto postDto1,
			@PathVariable Integer doctorId,
			@PathVariable Integer patientId)
	{
		postDto createPostDto=this.postService1.createPost(postDto1,doctorId,patientId);
		return new ResponseEntity<postDto>(createPostDto ,HttpStatus.CREATED);
		
	 }                                                    
	
	
	@GetMapping("/doctor1/{doctorId}/posts")
	public ResponseEntity<List<postDto>> getPostsByDoctor(
			@PathVariable Integer doctorId)
	{
		List<postDto> posts=this.postService1.getPostsByDoctor(doctorId);
		return new ResponseEntity<List<postDto>>(posts,HttpStatus.OK);
		
	}
	
	
	@GetMapping("/patient/{patientId}/posts")
	public ResponseEntity<List<postDto>> getPostsByPatient(
			@PathVariable Integer patientId)
	{
		List<postDto> posts=this.postService1.getPostsByPatient(patientId);
		return new ResponseEntity<List<postDto>>(posts,HttpStatus.OK);
		
	}
	
	
	//get all posts
	
	@GetMapping("/posts")
	public ResponseEntity<List<postDto>> getAllPost()
	{
		List<postDto> allPost=this.postService1.getAllPost();
		return new ResponseEntity<List<postDto>>(allPost,HttpStatus.OK);
	}
	
	
	//get post details by id
	
	
	@GetMapping("/posts/{postId}")
	public ResponseEntity<postDto> getPostById(@PathVariable Integer postId)
	{
		postDto postDto1=this.postService1.getPostById(postId);
		return new ResponseEntity<postDto>(postDto1,HttpStatus.OK);
		
	}
	
	
	//delete post
	@DeleteMapping("/posts/{postId}")
	public ApiResponse deletePost(@PathVariable Integer postId)
	{
		this.postService1.deletePost(postId);
		return new ApiResponse("Post is Successfully Deleted !!",true);
		
		
	}
	
	
	//update Post
	
	@PutMapping("/posts/{postId}")
	public ResponseEntity<postDto> updatePost(@RequestBody postDto postDto1,@PathVariable Integer postId)
	{
		postDto updatePost =postService1.updatePost(postDto1,postId);
		return new ResponseEntity<postDto>(updatePost,HttpStatus.OK);
		
		
	}
	
	
	//search
	@GetMapping("/posts/search/{keywords}")
	public ResponseEntity<List<postDto>> searchPostByPostTitle(
			@PathVariable("keywords") String keywords)
	{
		List<postDto> result=this.postService1.searchPosts(keywords);
		return new ResponseEntity<List<postDto>>(result,HttpStatus.OK);
	}
	
	
	//post image upload
	@PostMapping("/post/image/upload/{postId}")
	public ResponseEntity<postDto>  uploadImage(
			@RequestParam("image") MultipartFile image,
			@PathVariable Integer postId
			) throws IOException{ 
		postDto postDto1=this.postService1.getPostById(postId);
		String fileName=this.fileService.uploadImage(path, image);
		
		postDto1.setImageName(fileName);
		postDto updatePost=this.postService1.updatePost(postDto1, postId);
		return new ResponseEntity<postDto>(updatePost,HttpStatus.OK);
		
	}
	
	@GetMapping(value="/post/image/{imageName}",produces=MediaType.IMAGE_JPEG_VALUE)
	public void downloadImage(
			@PathVariable("imageName") String imageName,
			HttpServletResponse response
			) throws IOException
	{
		InputStream resource = this.fileService.getResource(path, imageName);
		response.setContentType(MediaType.IMAGE_JPEG_VALUE);
		StreamUtils.copy(resource,response.getOutputStream());
		
		
				
	}
	
	
	
	
}


