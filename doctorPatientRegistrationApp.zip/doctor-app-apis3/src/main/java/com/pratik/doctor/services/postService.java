package com.pratik.doctor.services;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.pratik.doctor.entities.post;
import com.pratik.doctor.payloads.postDto;


public interface postService {
	
	
	 postDto createPost(postDto postDto1,Integer doctorId,Integer patientId);
	 
	 
	 postDto updatePost(postDto postDto1,Integer postId);
	 
	 
	 void deletePost(Integer postId);
	 
	 
	 
	 List<postDto> getAllPost();
	 
	 
	 
	 
	 postDto getPostById(Integer postId);
	 
	 
	 
	 List<postDto> getPostsByPatient(Integer patientId);
	 
	 
	 
	 List<postDto> getPostsByDoctor(Integer doctorId);
	 
	 
	 
	 List<postDto> searchPosts(String keyword);
	 
	 
	 
	 
	 
	 

}

