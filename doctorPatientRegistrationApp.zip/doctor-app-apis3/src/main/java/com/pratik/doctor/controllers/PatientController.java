package com.pratik.doctor.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pratik.doctor.payloads.ApiResponse;
import com.pratik.doctor.payloads.PatientDto;
import com.pratik.doctor.payloads.doctorDto;
import com.pratik.doctor.services.PatientService;
import com.pratik.doctor.services.doctorService;

@RestController
@RequestMapping("/api/patients")
public class PatientController {
	
	
	@Autowired
	private PatientService patientService1;
	
	
	@PostMapping("/")
	public ResponseEntity<PatientDto> createPatient(@Valid @RequestBody PatientDto patientDto1)
	{
		PatientDto createPatientDto=this.patientService1.createPatient(patientDto1);
		return new ResponseEntity<PatientDto>(createPatientDto ,HttpStatus.CREATED);
		
		
		
	}
	
	
	
	@PutMapping("/{patientId}")
	public ResponseEntity<PatientDto> updatePatient(@Valid @RequestBody PatientDto patientDto1,@PathVariable("patientId") Integer patientId)
	{
		PatientDto updatedPatient=this.patientService1.updatePatient(patientDto1, patientId);
		return new ResponseEntity<PatientDto>(updatedPatient,HttpStatus.OK);
		
	}
	
	
	
	
	@DeleteMapping("/{patientId}")
	public ResponseEntity<ApiResponse> deletePatient(@PathVariable("patientId") Integer patientId)
	{
		this.patientService1.deletePatient(patientId);
		return new ResponseEntity<ApiResponse>(new ApiResponse("Patient Deleted Successfully", true),HttpStatus.OK);
	}
	
	
	
	@GetMapping("/{patientId}")
	public ResponseEntity<PatientDto> getPatient(@PathVariable Integer patientId)
	{
		PatientDto patientDto=this.patientService1.getPatient(patientId);
		return new ResponseEntity<PatientDto>(patientDto,HttpStatus.OK);
	}
	
	
	@GetMapping("/")
	public ResponseEntity<List<PatientDto>> getPatients()
	{
		List<PatientDto> patients=this.patientService1.getPatients();
		return ResponseEntity.ok(patients);
	}
	
	
	

}
