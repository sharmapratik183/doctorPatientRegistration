package com.pratik.doctor.services.impl;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pratik.doctor.entities.doctor;
import com.pratik.doctor.payloads.doctorDto;
import com.pratik.doctor.repositories.userRepo;
import com.pratik.doctor.services.doctorService;
import com.pratik.doctor.repositories.*;
import com.pratik.doctor.exceptions.*;
@Service
public class DoctorServiceImpl implements doctorService {
	@Autowired
	private userRepo userRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	

	@Override
	public doctorDto createDoctor(doctorDto doctorDto) {
		doctor doctor1=this.dtoToDoctor(doctorDto);
		doctor savedDoctor=this.userRepo.save(doctor1);
		return this.doctorToDto(savedDoctor);
		
	}

	@Override
	public doctorDto updateDoctor(doctorDto doctorDto, Integer doctorId) {
		doctor doctor1=this.userRepo.findById(doctorId)
				.orElseThrow(() -> new ResourceNotFoundException("doctor","id",doctorId));
		doctor1.setName(doctorDto.getName());
		doctor1.setEmail(doctorDto.getEmail());
		doctor1.setCity(doctorDto.getCity());
		doctor1.setPhone(doctorDto.getPhone());
		doctor1.setSpeciality(doctorDto.getSpeciality());
		doctor updatedDoctor=this.userRepo.save(doctor1);
		doctorDto doctorDto1=this.doctorToDto(updatedDoctor);
		return doctorDto1;
	}

	@Override
	public doctorDto getDoctorById(Integer doctorId)
	{
		doctor doctor1 = this.userRepo.findById(doctorId).orElseThrow( () -> new ResourceNotFoundException("doctor","id", doctorId));
		
		return this.doctorToDto(doctor1);
		
	}

	@Override
	public List<doctorDto> getAllDoctors() {
		List<doctor> doctors=this.userRepo.findAll();
		List<doctorDto> doctorDtos=doctors.stream().map(doctor->this.doctorToDto(doctor)).collect(Collectors.toList());
		
		return doctorDtos;
	}

	@Override
	public void deleteDoctor(Integer doctorId) {
		doctor doctor1=this.userRepo.findById(doctorId).orElseThrow( ()-> new ResourceNotFoundException("doctor","id",doctorId));
		this.userRepo.delete(doctor1);

	}
	
	public doctor dtoToDoctor(doctorDto doctorDto)
	{
		doctor doctor1=this.modelMapper.map(doctorDto, doctor.class);
		
		
//		doctor1.setId(doctorDto.getId());
//		doctor1.setName(doctorDto.getName());
//		doctor1.setEmail(doctorDto.getEmail());
//		doctor1.setCity(doctorDto.getCity());
//		doctor1.setPhone(doctorDto.getPhone());
//		doctor1.setSpeciality(doctorDto.getSpeciality());
		return doctor1;
		
		
	}
	
	public doctorDto doctorToDto(doctor doctor2)
	{
		doctorDto doctorDto1=this.modelMapper.map(doctor2, doctorDto.class);
		
//		doctorDto1.setId(doctor2.getId());
//		doctorDto1.setName(doctor2.getName());
//		doctorDto1.setEmail(doctor2.getEmail());
//		doctorDto1.setCity(doctor2.getCity());
//		doctorDto1.setPhone(doctor2.getPhone());
//		doctorDto1.setSpeciality(doctor2.getSpeciality());
		return doctorDto1;
		
		
	}
	

}
